#!/bin/bash
export GH_REPO=simplessr/SSR-Bash-Python # 修改此处以使用尚存的GitHub Repos